#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include "Deplacements_et_Actions.h"

void init_mat(int mat[N][N]){
	for(int i = 0; i < N; i++){
		for(int j = 0; j < N; j++){
			mat[i][j] = 0;
		}
	}
}

void aff_mat(int mat[N][N]){
	for(int i = 0; i < N; i++){
		printf("\n");
		for(int j = 0; j < N; j++){
			printf("| %i |", mat[i][j]);
		}
	}
	printf("\n\n");
}

int positionner_sbires(t_sbires sbires, int pos, int mat[N][N]){
	if(mat[sbires.position[0]][sbires.position[1]] == 0){
		mat[sbires.position[0]][sbires.position[1]] = pos;
		return 1;
	} else {
		printf("La case %i - %i est déjà occupée\n", sbires.position[0], sbires.position[1]);
		return 0;
	}
}

t_sbires init_armee(t_sbires sbires, int mat[N][N]){
	int poser = 0;
	sbires.nom = malloc(sizeof(char)*128);
	printf("\nNom de l'unité : ");
	scanf("%s", sbires.nom);
	if( (strcmp(sbires.nom, "dummy") == 0) || (strcmp(sbires.nom, "Dummy") == 0) ){
		sbires.attaque = 0;
		sbires.defense = 10;
		sbires.vie = 50;
		sbires.mana = 0;
		sbires.esquive = 10;
		sbires.nbr_depl = 0;
		sbires.position[0] = 5;
		sbires.position[1] = 6;
		poser = positionner_sbires(sbires, 2, mat);
		printf("\nThat's one good sturdy dummy !\n");
	} else {
		sbires.attaque = 30;
		sbires.defense = 20;
		sbires.vie = 50;
		sbires.mana = 20;
		sbires.esquive = 30;
		sbires.nbr_depl = 5;
		printf("Position de départ : \n");
		while(poser == 0){
			for(int n = 0; n < 2; n++){
				if(n == 0){
					printf("Ligne : ");
				} else {
					printf("Colonne : ");
				}
				scanf("%i", &sbires.position[n]);
			}
			poser = positionner_sbires(sbires, 1, mat);
		}
	}
	printf("\nSbire %s créé : \n", sbires.nom);
	printf("Attaque : %i \nDefense : %i \nMana : %i \nVie : %i \nTaux d'esquive : %i pourcents\nNombre de pas possibles : %i \n", sbires.attaque, sbires.defense, sbires.mana, sbires.vie, sbires.esquive, sbires.nbr_depl);
}



int main (void) {
	int mat[N][N];
	init_mat(mat);
	t_sbires sbire;
	sbire = init_armee(sbire, mat);
	t_sbires dummy;
	dummy = init_armee(dummy, mat);
	aff_mat(mat);
	Selection_Action(sbire, dummy, mat);
}
